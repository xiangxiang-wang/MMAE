function [evals] = Copy_2_of_evalution_20240823(imgA, imgB, imgF,image1,image2,fused_image)
%% ���ö�������ָ����ں�Ч����������
evals(1) = Edge_Intensity(imgF); % ��Եǿ�� EI
evals(2) = avg_gradient(imgF);    %ƽ���ݶ� AG
evals(3) = std2(imgF);       % SD
evals(4) = MySF(imgF);    % �ռ�Ƶ�ʡ�x,y�� SF2

evals(5)  = (vifvec(im2double(imgA),im2double(imgF))+vifvec(im2double(imgB),im2double(imgF)))/2;%vif
evals(6) = VIFF_Public(imgA, imgB, imgF);  %VIFF

evals(7) = OverallCrossEntropy(imgA, imgB, imgF); % ����ƽ��������
evals(8) = entropy(imgF); % EN
evals(9) = analysis_MI(imgA,imgB,imgF);%MI
% evals(6) = entropy(imgF); % EN
% evals(7) = analysis_MI(imgA,imgB,imgF);%MI
evals(10) = analysis_fmi(imgA,imgB,imgF,'wavelet');%FMI_w
evals(11) = analysis_fmi(imgA,imgB,imgF,'dct');%FMI_dct
evals(12) = analysis_fmi(imgA,imgB,imgF);%FMI_pixel
% 
% evals(13) = analysis_ssim(imgA,imgB,imgF); %ssim
evals(14) = analysis_MSSSIM(imgA,imgB,imgF); %MSSSIM
% 
% evals(15) = (psnr(imgA,imgF)+psnr(imgB,imgF))/2; %PSNR
evals(16) = analysis_SCD(imgA,imgB,imgF); %SCD
evals(17) = analysis_Qabf(imgA,imgB,imgF); %Qabf
evals(18) = analysis_nabf(imgF,imgA,imgB); %Nabf
evals(19) = metricZheng(imgA, imgB,imgF); % QSF
evals(20) = metricMI(imgA,imgB,imgF,1);   % QMI
evals(21) = metricPeilla(imgA, imgB, imgF, 1);      % QS
evals(22) = metricPeilla(imgA, imgB, imgF, 2);      % QW
evals(23) = metricPeilla(imgA, imgB, imgF, 3);      % QE
evals(24) = metricWang(imgA, imgB, double(imgF));  % QNCIE
evals(25) = metricXydeas(imgA, imgB, imgF);      % QG
evals(26) = my_cc(imgA, imgB, imgF);     % CC
evals(27) = metricZhao(imgA, imgB, imgF);      % QP
evals(28) = metricChen(imgA, imgB, imgF);      % QCV
evals(29) = metricChenBlum(imgA, imgB, imgF);      % QCB

imgA=image1;
imgB=image2;
imgF=fused_image;

% rgb and rgb

evals(15) = (Copy_of_psnr_2024(imgF,imgA)+Copy_of_psnr_2024(imgF,imgB))/2; %PSNR
F_c1 = imgF(:,:,1);
F_c2 = imgF(:,:,2);
F_c3 = imgF(:,:,3);
A_c1 = imgA(:,:,1);
A_c2 = imgA(:,:,2);
A_c3 = imgA(:,:,3);
B_c1 = imgB(:,:,1);
B_c2 = imgB(:,:,2);
B_c3 = imgB(:,:,3);
[ssim_1c1,~] = ssim(F_c1,A_c1);
[ssim_1c2,~] = ssim(F_c2,A_c2);
[ssim_1c3,~] = ssim(F_c3,A_c3);
[ssim_2c1,~] = ssim(F_c1,B_c1);
[ssim_2c2,~] = ssim(F_c2,B_c2);
[ssim_2c3,~] = ssim(F_c3,B_c3);
ssim1 = (ssim_1c1+ssim_1c2+ssim_1c3)/3;
ssim2 = (ssim_2c1+ssim_2c2+ssim_2c3)/3;
evals(13) = (ssim1+ssim2)/2;%ssim


% rgb and gary
% imgB_(:,:,1) = imgB;
% imgB_(:,:,2) = imgB;
% imgB_(:,:,3) = imgB;
% evals(15) = (Copy_of_psnr_2024(imgF,imgA)+Copy_of_psnr_2024(imgF,imgB_))/2; %PSNR
% F_c1 = imgF(:,:,1);
% F_c2 = imgF(:,:,2);
% F_c3 = imgF(:,:,3);
% A_c1 = imgA(:,:,1);
% A_c2 = imgA(:,:,2);
% A_c3 = imgA(:,:,3);
% B_c1 = imgB_(:,:,1);
% B_c2 = imgB_(:,:,2);
% B_c3 = imgB_(:,:,3);
% [ssim_1c1,~] = ssim(F_c1,A_c1);
% [ssim_1c2,~] = ssim(F_c2,A_c2);
% [ssim_1c3,~] = ssim(F_c3,A_c3);
% [ssim_2c1,~] = ssim(F_c1,B_c1);
% [ssim_2c2,~] = ssim(F_c2,B_c2);
% [ssim_2c3,~] = ssim(F_c3,B_c3);
% ssim1 = (ssim_1c1+ssim_1c2+ssim_1c3)/3;
% ssim2 = (ssim_2c1+ssim_2c2+ssim_2c3)/3;
% evals(13) = (ssim1+ssim2)/2;%ssim




end
