%多曝光图像评价指标
clc;
clear all;
% setenv('MW_MINGW64_LOC','D:\mingw64')
% mex -setup C++
% mex C:\Users\Administrator\Documents\BaiduSyncdisk\assessment\VIF\matlabPyrTools-master\MEX\corrDn.c convolve.c edges.c edges-orig.c
%融合图像存放路径
fused_path = 'E:\ref4_results\新建文件夹\test_results1212_SICE_MEF1';
source_path = 'F:\test_dataset\SICE_MEF1_select2';
% fused_path = 'C:\Users\Administrator\Documents\BaiduSyncdisk\compute\lytro\MFF-GAN';
% source_path = 'C:\Users\Administrator\Documents\BaiduSyncdisk\set\lytro';
% [fused_namelist,fused_nums] = getimglist(fused_path);
% [source_namelist,source_nums] = getimglist(source_path);
%后缀名
% fused_suffix = '.jpg';
fused_suffix = '.png';
% fused_suffix = '.bmp';
%图片数量
fused_nums = 10;
source_nums = 10;
%融合结果名称
fused_namelist = ["52","130","139","147","148","250","288","300","305","312"];

%源图像名称
source_namelist = ["52","130","139","147","148","250","288","300","305","312"];


for i =1:fused_nums
   disp(['name ',source_namelist(i),'  image:',num2str(i)]);
   source_img1  = strcat(source_path,'/',"source_1",'/',source_namelist(i),'.jpg');
   source_img2 = strcat(source_path,'/',"source_2",'/',source_namelist(i),'.jpg');
   image1 = imread(source_img1);
   image2 = imread(source_img2);
   if size(image1, 3) == 3
       image1 = rgb2gray(image1);
   end
   if size(image2, 3) == 3
       image2 = rgb2gray(image2);
   end
   fused = strcat(fused_path,'/',fused_namelist(i),fused_suffix);
   fused_image = imread(fused);
   if size(fused_image, 3) == 3
       fused_image = rgb2gray(fused_image);
   end
%    image1 = double(image1);
%    image2 = double(image2);
%    fused_image = double(fused_image);

   result = evalution(image1,image2,fused_image);
   a(i,:) = result;
%     a(i,:) = i;

end
b(:) = sum(a(:,:))/fused_nums;

save_path = strcat(fused_path,'/','each_image');
save(save_path,'a') ;
save_path = strcat(fused_path);
save(save_path,'b') ;
disp("评价结束");
