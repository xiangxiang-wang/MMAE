function [namelist,nums] = getimglist(imgpath)
%getimglist 得到文件名列表
%   此处提供详细说明
imglist = dir(imgpath);  %得到文件名列表
len = length(imglist);
nums = len-2;
namelist = strings(nums,1);
for i=3:len
   name = imglist(i,1).name;
   namelist(i-2) = char(name);
end
end