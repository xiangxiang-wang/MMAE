%多曝光图像评价指标
clc;
clear all;
% % setenv('MW_MINGW64_LOC','D:\mingw64')
% % mex -setup C++
% % mex C:\Users\Administrator\Documents\BaiduSyncdisk\assessment\VIF\matlabPyrTools-master\MEX\corrDn.c convolve.c edges.c edges-orig.c
% %融合图像存放路径
% fused_path = 'D:\BaiduSyncdisk\diffusion-fusion\test_results_DDPM_fusion39\SICE_our3-2';
% source_path = 'F:\test_dataset\SICE_MEF3_select2';
% % fused_path = 'C:\Users\Administrator\Documents\BaiduSyncdisk\compute\lytro\MFF-GAN';
% % source_path = 'C:\Users\Administrator\Documents\BaiduSyncdisk\set\lytro';
% % [fused_namelist,fused_nums] = getimglist(fused_path);
% % [source_namelist,source_nums] = getimglist(source_path);
% %后缀名
% % fused_suffix = '.jpg';
% fused_suffix = '.png';
% % fused_suffix = '.bmp';
% %图片数量
% fused_nums = 5;
% source_nums = 5;
% %融合结果名称
% fused_namelist = ["1","2","3","4","5"];
% 
% %源图像名称
% source_namelist = ["1","2","3","4","5"];

%融合图像存放路径
fused_path = 'D:\BaiduSyncdisk\diffusion-fusion\test_result_20240111\sice3-3';
%源图像存放路径
source_path = 'F:\test_dataset\SICE_MEF3_select2';
source_img1_path = strcat(source_path,'/',"source_1");
namelist = dir(fullfile(source_img1_path));
size_row = size(namelist);
folder_num = size_row(1);
name = {};
for i=3:folder_num
    fileNames_folder = namelist(i).name;
    fileNames_folder2 =fileNames_folder(1:end-4);
    ext = fileNames_folder(end-2:end);
    name{end+1}=fileNames_folder2;
end
fused_nums = folder_num-2;

%融合结果名称
fused_namelist = string(name);
%源图像名称
source_namelist = fused_namelist
%后缀名
fused_suffix = '.png';

for i =1:fused_nums
   disp(['name ',source_namelist(i),'  image:',num2str(i)]);
   source_img1  = strcat(source_path,'/',"source_1",'/',source_namelist(i),'.png');
   source_img2 = strcat(source_path,'/',"source_2",'/',source_namelist(i),'.png');
   image1 = imread(source_img1);
   image2 = imread(source_img2);
   if size(image1, 3) == 3
       image1 = rgb2gray(image1);
   end
   if size(image2, 3) == 3
       image2 = rgb2gray(image2);
   end
   fused = strcat(fused_path,'/',fused_namelist(i),fused_suffix);
   fused_image = imread(fused);
   if size(fused_image, 3) == 3
       fused_image = rgb2gray(fused_image);
   end
%    image1 = double(image1);
%    image2 = double(image2);
%    fused_image = double(fused_image);

   result = Copy_of_evalution(image1,image2,fused_image);
   a(i,:) = result;
%     a(i,:) = i;

end
b(:) = sum(a(:,:))/fused_nums;

save_path = strcat(fused_path,'/','each_image');
save(save_path,'a') ;
save_path = strcat(fused_path);
save(save_path,'b') ;
disp("评价结束");
