%多聚焦图像评价指标
clc;
clear all;
% setenv('MW_MINGW64_LOC','D:\mingw64')
% mex -setup C++
% mex C:\Users\Administrator\Documents\BaiduSyncdisk\assessment\VIF\matlabPyrTools-master\MEX\corrDn.c convolve.c edges.c edges-orig.c
%融合图像存放路径
fused_path = 'D:\BaiduSyncdisk\compute\lytro\our829';
source_path = 'D:\DeepLearing\set\lytro';
% fused_path = 'C:\Users\Administrator\Documents\BaiduSyncdisk\compute\lytro\MFF-GAN';
% source_path = 'C:\Users\Administrator\Documents\BaiduSyncdisk\set\lytro';
% [fused_namelist,fused_nums] = getimglist(fused_path);
% [source_namelist,source_nums] = getimglist(source_path);
%后缀名
% fused_suffix = '.jpg';
fused_suffix = '.png';
% fused_suffix = '.bmp';
%图片数量
fused_nums = 20;
source_nums = 20;
%融合结果名称
fused_namelist = ["lytro-01","lytro-02","lytro-03","lytro-04","lytro-05","lytro-06","lytro-07","lytro-08","lytro-09","lytro-10","lytro-11","lytro-12","lytro-13","lytro-14","lytro-15","lytro-16","lytro-17","lytro-18","lytro-19","lytro-20"];
% fused_namelist = ["IFCNN-SUM-CMF-lytro-01","IFCNN-SUM-CMF-lytro-02","IFCNN-SUM-CMF-lytro-03","IFCNN-SUM-CMF-lytro-04","IFCNN-SUM-CMF-lytro-05","IFCNN-SUM-CMF-lytro-06","IFCNN-SUM-CMF-lytro-07","IFCNN-SUM-CMF-lytro-08","IFCNN-SUM-CMF-lytro-09","IFCNN-SUM-CMF-lytro-10","IFCNN-SUM-CMF-lytro-11","IFCNN-SUM-CMF-lytro-12","IFCNN-SUM-CMF-lytro-13","IFCNN-SUM-CMF-lytro-14","IFCNN-SUM-CMF-lytro-15","IFCNN-SUM-CMF-lytro-16","IFCNN-SUM-CMF-lytro-17","IFCNN-SUM-CMF-lytro-18","IFCNN-SUM-CMF-lytro-19","IFCNN-SUM-CMF-lytro-20"];
% fused_namelist = ["color_lytro_01","color_lytro_02","color_lytro_03","color_lytro_04","color_lytro_05","color_lytro_06","color_lytro_07","color_lytro_08","color_lytro_09","color_lytro_10","color_lytro_11","color_lytro_12","color_lytro_13","color_lytro_14","color_lytro_15","color_lytro_16","color_lytro_17","color_lytro_18","color_lytro_19","color_lytro_20"];
% fused_namelist = ["1_FFMEF","2_FFMEF","3_FFMEF","4_FFMEF","5_FFMEF","6_FFMEF","7_FFMEF","8_FFMEF","9_FFMEF","10_FFMEF","11_FFMEF","12_FFMEF","13_FFMEF","14_FFMEF","15_FFMEF","16_FFMEF","17_FFMEF","18_FFMEF","19_FFMEF","20_FFMEF"];
% fused_namelist = ["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20"];
% fused_namelist = ["Lytro_fusion_1","Lytro_fusion_2","Lytro_fusion_3","Lytro_fusion_4","Lytro_fusion_5","Lytro_fusion_6","Lytro_fusion_7","Lytro_fusion_8","Lytro_fusion_9","Lytro_fusion_10","Lytro_fusion_11","Lytro_fusion_12","Lytro_fusion_13","Lytro_fusion_14","Lytro_fusion_15","Lytro_fusion_16","Lytro_fusion_17","Lytro_fusion_18","Lytro_fusion_19","Lytro_fusion_20"];

%源图像名称
source_namelist = ["lytro-01","lytro-02","lytro-03","lytro-04","lytro-05","lytro-06","lytro-07","lytro-08","lytro-09","lytro-10","lytro-11","lytro-12","lytro-13","lytro-14","lytro-15","lytro-16","lytro-17","lytro-18","lytro-19","lytro-20"];


for i =1:fused_nums
   disp(['name ',source_namelist(i),'  image:',num2str(i)]);
   source_img1  = strcat(source_path,'/',source_namelist(i),'/',source_namelist(i),'-A.jpg');
   source_img2 = strcat(source_path,'/',source_namelist(i),'/',source_namelist(i),'-B.jpg');
   image1 = imread(source_img1);
   image2 = imread(source_img2);
   if size(image1, 3) == 3
       image1 = rgb2gray(image1);
   end
   if size(image2, 3) == 3
       image2 = rgb2gray(image2);
   end
   fused = strcat(fused_path,'/',fused_namelist(i),fused_suffix);
   fused_image = imread(fused);
   if size(fused_image, 3) == 3
       fused_image = rgb2gray(fused_image);
   end
%    image1 = double(image1);
%    image2 = double(image2);
%    fused_image = double(fused_image);

   result = evalution(image1,image2,fused_image);
   a(i,:) = result;
%     a(i,:) = i;

end
b(:) = sum(a(:,:))/fused_nums;

save_path = strcat(fused_path,'/','each_image');
save(save_path,'a') ;
save_path = strcat(fused_path);
save(save_path,'b') ;
disp("评价结束");
