function [evals] = evalution(imgA, imgB, imgF)
%% ���ö�������ָ����ں�Ч����������
evals(1) = Edge_Intensity(imgF); % ��Եǿ�� EI
evals(2) = avg_gradient(imgF);    %ƽ���ݶ� AG
evals(3) = std2(imgF);       % SD
evals(4) = MySF(imgF);    % �ռ�Ƶ�ʡ�x,y�� SF2

evals(5)  = (vifvec(im2double(imgA),im2double(imgF))+vifvec(im2double(imgB),im2double(imgF)))/2;%vif
evals(6) = VIFF_Public(imgA, imgB, imgF);  %VIFF

evals(7) = OverallCrossEntropy(imgA, imgB, imgF); % ����ƽ��������
evals(8) = entropy(imgF); % EN
evals(9) = analysis_MI(imgA,imgB,imgF);%MI
evals(10) = analysis_fmi(imgA,imgB,imgF,'wavelet');%FMI_w
evals(11) = analysis_fmi(imgA,imgB,imgF,'dct');%FMI_dct
evals(12) = analysis_fmi(imgA,imgB,imgF);%FMI_pixel

evals(13) = analysis_ssim(imgA,imgB,imgF); %ssim
evals(14) = analysis_MSSSIM(imgA,imgB,imgF); %MSSSIM

evals(15) = (psnr(imgA,imgF)+psnr(imgB,imgF))/2; %PSNR
evals(16) = analysis_SCD(imgA,imgB,imgF); %SCD
evals(17) = analysis_Qabf(imgA,imgB,imgF); %Qabf
evals(18) = analysis_nabf(imgF,imgA,imgB); %Nabf
evals(19) = metricZheng(imgA, imgB,imgF); % QSF
evals(20) = metricMI(imgA,imgB,imgF,1);   % QMI
evals(21) = metricPeilla(imgA, imgB, imgF, 1);      % QS
evals(22) = metricPeilla(imgA, imgB, imgF, 2);      % QW
evals(23) = metricPeilla(imgA, imgB, imgF, 3);      % QE
% evals(24)= metricYang(imgA, imgB, imgF);      % QY
% evals(25) = metricCvejic(imgA, imgB, imgF,2);      % QC
% evals(26) = metricWang(imgA, imgB, double(imgF));  % QNCIE
% evals(27) = metricXydeas(imgA, imgB, imgF);      % QG
% evals(28) = my_cc(imgA, imgB, imgF);     % CC
% evals(29) = metricZhao(imgA, imgB, imgF);      % QP
% evals(30) = metricChen(imgA, imgB, imgF);      % QCV
% evals(31) = metricChenBlum(imgA, imgB, imgF);      % QCB
evals(24) = metricWang(imgA, imgB, double(imgF));  % QNCIE
evals(25) = metricXydeas(imgA, imgB, imgF);      % QG
evals(26) = my_cc(imgA, imgB, imgF);     % CC
evals(27) = metricZhao(imgA, imgB, imgF);      % QP
evals(28) = metricChen(imgA, imgB, imgF);      % QCV
evals(29) = metricChenBlum(imgA, imgB, imgF);      % QCB






end
