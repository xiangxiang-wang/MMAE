clc
clear all
fused_path = 'C:\Users\Administrator\Documents\BaiduSyncdisk\compute\lytro\MFF-GAN';
source_path = 'C:\Users\Administrator\Documents\BaiduSyncdisk\set\lytro\lytro-01\lytro-01';
source_img1  = strcat(source_path,'-A.jpg');
source_img2 = strcat(source_path,'-B.jpg');
image1 = imread(source_img1);
image2 = imread(source_img2);
if size(image1, 3) == 3
    image1 = rgb2gray(image1);
end
if size(image2, 3) == 3
    image2 = rgb2gray(image2);
end

fused = strcat(fused_path,'/1.png');
fused_image = imread(fused);

if size(fused_image, 3) == 3
    fused_image = rgb2gray(fused_image);
end

image1 = double(image1);
image2 = double(image2);
fused_image = double(fused_image);

% md = (image1 - fused_image).^2;
% mdsize = size(md);
% summation = 0;
% for  i = 1:mdsize(1)
%     for j = 1:mdsize(2)
%         summation = summation + abs(md(i,j));
%     end
% end
% disp(summation);
% x = sum(sum(md));
% disp(x)
% 
evals = (psnr(image1,fused_image)+psnr(image2,fused_image))/2; %PSNR
disp(psnr(image1,fused_image))
disp(psnr(image2,fused_image))
disp(evals)

